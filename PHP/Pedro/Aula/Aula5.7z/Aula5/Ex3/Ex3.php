<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EstruturaRepeticao</title>
</head>
<body>

<?php

$numeros = $_GET['numeros']; // Array de números enviados pelo formulário


$menor = null;
$maior = null;

foreach ($numeros as $numero) {
    if ($numero == 0) {
        break; // Encerra a leitura ao encontrar o zero
    }

    if ($menor === null || $numero < $menor) {
        $menor = $numero;  // Atualiza o menor número
    }

    if ($maior === null || $numero > $maior) {
        $maior = $numero;  // Atualiza o maior número
    }
}

if ($menor === null) {
    echo "Nenhum número válido foi digitado antes do zero.<br>";
} else {
    echo "Menor número digitado: $menor<br>";
    echo "Maior número digitado: $maior<br>";
}
?>
    
</body>
</html>