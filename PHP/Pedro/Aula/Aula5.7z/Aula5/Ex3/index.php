<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EstruturaRepeticao</title>
</head>
<body>

<form action="Ex3.php" method="GET">
        <label for="numeros">Valor:</label>     
        <input name="numeros" type="number" placeholder="ex: 1"></input>
        
        <button tipe="submit">Calcular</button>
    </form>
    
</body>
</html>